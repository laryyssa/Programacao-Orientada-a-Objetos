/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.arraysl;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author larys
 */
public class ArraysL {
    public static int leia(String mensagem){
        Scanner teclado = new Scanner(System.in);
        System.out.print(mensagem);
        return teclado.nextInt();
    }

    public static void main(String[] args) {
       ArrayList<Integer> arrayL = new ArrayList<>();
       int resposta, num;
       
       do {
           resposta = leia("Digite: 1- INSERIR; 2 - RETIRAR; 3 - IMPRIMIR; 0 - SAIR => ");
           
           switch(resposta){
               case 1:
                   if(arrayL.size()<5){
                       num = leia("Digite o Número a ser inserido no Array: ");
                       arrayL.add(num);
                   
                    } else {
                       System.out.println("ERRO: Não é possível inserir mais que 5 elementos!");
                   }
                   break;
                
               case 2:
                   num = leia("Digite a posição que deseja remover: ");
                   if (num >= 5 || num < 0){
                       System.out.print("ERRO: Não existe essa posição.");
                   } else if (num >= arrayL.size()){ 
                       System.out.print("ERRO: Não há número nessa posição!");
                   } else{   
                       arrayL.remove(num);
                   }
                   break;
                   
               case 3:
                   System.out.print("| ");
                   for (int i: arrayL){
                       System.out.print(i +" | ");
                   }
                   System.out.println("");
                   break;
                   
               default:
                   System.out.print("Número inválido! Tente novamente.");
                  
                      
           } 
           
           System.out.println("");
           
       }while (resposta != 0);
       
       
      
    }
}
